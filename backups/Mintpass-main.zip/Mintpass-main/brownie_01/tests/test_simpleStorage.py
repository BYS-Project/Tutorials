# Solito import
from brownie import SimpleStorage, accounts

def testDeploy():
    # Arrange: set up all the pieces
    account = accounts[0]
    # Acting: deploy the contract
    simpleStorage = SimpleStorage.deploy({"from" : account})
    startValue = simpleStorage.getNumber()
    expected = 1
    # Asserting: controllare che i valori siano giusti
    assert startValue == expected

def testUpdate():
    # Arrange: set up all the pieces
    account = accounts[0]
    # Acting: deploy the contract
    simpleStorage = SimpleStorage.deploy({"from" : account})
    simpleStorage.updateNumber(15, {"from" : account})
    newValue = simpleStorage.getNumber()
    expected = 15
    # Asserting: controllare che i valori siano giusti
    assert newValue == expected