from brownie import FundMe
from scripts.commonScripts import getAccount
from scripts.deploy import deploy

def fund():
    if len(FundMe) <= 0:
        deploy()
    fundMe = FundMe[-1]
    account = getAccount()
    fundMe.acceptPayments({"from" : account, "value" : 2000000000000000000})

def withdraw():
    fundMe = FundMe[-1]
    account = getAccount()
    fundMe.withdraw({"from" : account})

def main():
    fund()
    withdraw()
    