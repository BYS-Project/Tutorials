from brownie import FundMe, MockV3Aggregator, network, config
from scripts.commonScripts import getAccount, deployMocks, LOCAL_BLOCKCHAIN_ENVIRONMENTS



def deploy():
    account = getAccount()
    print(f"Found account: {account}")
    priceFeed = getPriceFeed()

    # Aggiungendo publish_source = True diciamo che vogliamo pubblicare il codice sorgente
    fundMe = FundMe.deploy(priceFeed, {"from" : account})
    print(f"Contract deployed to {fundMe.address}")

def getPriceFeed():
    if network.show_active() not in LOCAL_BLOCKCHAIN_ENVIRONMENTS:
        priceFeed = config["networks"][network.show_active()].get("eth_usd")
    else:
        deployMocks()
        priceFeed = MockV3Aggregator[-1].address
    return priceFeed

def main():
    deploy()