from brownie import FundMe, network, accounts, exceptions
from scripts.commonScripts import getAccount, FORKED_ENVIRONMENTS, LOCAL_BLOCKCHAIN_ENVIRONMENTS
from scripts.deploy import getPriceFeed
import pytest

AMOUNT = 2000000000000000000

def testCanPay():
    account = getAccount()
    fundMe = FundMe.deploy(getPriceFeed(), {"from" : account})
    tx = fundMe.acceptPayments({"from" : account, "value" : AMOUNT})
    tx.wait(1)
    assert fundMe.payments(account.address) == AMOUNT

def testCanWithdraw():
    account = getAccount()
    fundMe = FundMe.deploy(getPriceFeed(), {"from" : account})
    tx = fundMe.withdraw({"from" : account})
    tx.wait(1)
    assert fundMe.payments(account.address) == 0

def testOwnerWithdraw():
    if network.show_active() not in LOCAL_BLOCKCHAIN_ENVIRONMENTS and network.show_active() not in FORKED_ENVIRONMENTS:
        pytest.skip("only for local testing")
    account = getAccount()
    notOwnerAccount = accounts[1]
    fundMe = FundMe.deploy(getPriceFeed(), {"from" : account})
    # Se c'è un exception in questa parte di codice, è giusto
    # Sono necessarie delle altre (...) nel caso in cui avessimo più eccezioni
    with pytest.raises( (ValueError, exceptions.VirtualMachineError) ):
        fundMe.withdraw({"from" : notOwnerAccount})