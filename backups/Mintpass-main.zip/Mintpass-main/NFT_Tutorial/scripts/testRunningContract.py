from web3 import Web3
from brownie import Contract, NFT_Contract
from scripts import commonScripts

def main():
    address = "0x013bE633e2373e940301E4b688609C09D5Edf7af"
    url = "https://rinkeby.infura.io/v3/62892642961b44c7897f9283f240f76d"
    web3 = Web3(Web3.HTTPProvider(url))
    print("Is connected to infura? ", web3.isConnected())
    account = commonScripts.getAccount()

    contract = Contract.from_abi("NFT_Contract", address, NFT_Contract.abi)
    #print("Contract Supply: ", contract.totalSupply())
    contract.mint("0x705ADdE55cFEfF70FA8F29f191a57c4337aa13f3", "ipfs://QmY8uaE5DXHdoSpfLG8jDb8PAr5rYFcENVhNn2wCxHC6XY", {"from" : account})
    #print("Contract Supply: ", contract.totalSupply())
    #contract.setBaseURI("https://www.nukecraft.net/tests/nft/metadata/", {"from":account})
    print("TokenExtensions: ", contract.tokenURI(0))

