from scripts.commonScripts import getAccount
from brownie import NFT_Contract

def deploy():
    extension = ".json"
    account = getAccount()
    contract = NFT_Contract.deploy(extension, {"from" : account})
    return contract

def main():
    deploy()