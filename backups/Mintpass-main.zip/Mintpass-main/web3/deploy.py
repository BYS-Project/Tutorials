# Per quanto riguarda gli smart contract
from solcx import compile_standard, install_solc
# Per il JSon
import json
# Per le variabili d'ambiente
import os
from dotenv import load_dotenv
# Libreria di gestione blockchain
from web3 import Web3

load_dotenv()
install_solc("0.6.0")

with open("./SimpleStorage.sol", "r") as file:
    simpleStorageFile = file.read()

# Compiliamo
compiledSolidity = compile_standard(
    {
        "language": "Solidity",
        "sources": {"SimpleStorage.sol" : {"content" : simpleStorageFile}},
        "settings": {
            "outputSelection": {
                "*": { "*": ["abi", "metadata", "evm.bytecode", "evm.sourceMap"] }
            }
        },
    },
    solc_version = "0.6.0"
)

with open("compliedCode.json", "w") as file:
    json.dump(compiledSolidity, file)

# Per fare il deploy abbiamo bisogno del bytecode del file
bytecode = compiledSolidity["contracts"]["SimpleStorage.sol"]["SimpleStorage"]["evm"]["bytecode"]["object"]
# E anche dell'ABI
abi = compiledSolidity["contracts"]["SimpleStorage.sol"]["SimpleStorage"]["abi"]

# Ora dobbiamo fare il deploy (Su Quale BlockChaint)
# Per l'ambiente simulato non c'è più Javascript ma c'è Local Ganache Chain (https://trufflesuite.com/ganache/)

# Per connettersi a ganache
w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:8545"))
# Ora necessitiamo dell'ID del network
chainId = 1337 
# Necessitiamo di un address dal quale fare il deploy
myAddress = "0xB2CFf01491C4D9f9DA54EbADd21718a8Dc69d03B"
# Infine ci serve la chiave privata dell'indirizzo per firmare le transazioni (aggiungere 0x)
# Ovviamente non è una best-practice hardcoddare la private key (si ruberebbe facilmente)
#    Per evitare di fare in questo modo si setta una variabile d'ambiente
#    In Linux/Mac: -> export <nomeVariabile> = <valoreVariabile> (echo <nomeVariabile> per richiamarla)
#    In Windows: -> https://www.twilio.com/blog/2017/01/how-to-set-environment-variables.html
#    Nota: se non la trova prova a riavviare la console

#    Oppure si fa un file .env (non da caricare (aggiungi nel .gitignore)) dove si mettono le variabili con formato:
#        export <nomeVariabile>=<valoreVariabile>
#        export <nomeVariabile2>=<valoreVariabile2>
#    Necessario python-dotenv per utilizzarlo
#    from dotenv import load_dotenv
#    load_dotenv() -> Ora le variabili dovrebbero essere state caricate
privateKey = os.environ.get("PRIVATEKEY")
# Ora possiamo fare il deploy
simpleStorage = w3.eth.contract(abi=abi, bytecode=bytecode)
# Ricevi l'ultima transazione
nonce = w3.eth.getTransactionCount(myAddress)
# Per fare una transazione:
# 1) Costruisci una transazione
transaction = simpleStorage.constructor().buildTransaction({"chainId": chainId, "from": myAddress, "nonce": nonce, "gasPrice": w3.eth.gas_price})
#  print(transaction)
# 2) Firma una transazione
signedTransaction = w3.eth.account.sign_transaction(transaction, private_key=privateKey)
# 3) Manda una transazione
transactionHash = w3.eth.send_raw_transaction(signedTransaction.rawTransaction)
# -> Ora abbiamo creato un contratto visibile da Gananche / Transactions
# Ora aspettiamo per la conferma dei blocchi
transactionReceipt = w3.eth.wait_for_transaction_receipt(transactionHash)

# Per lavorare con un contratto abbiamo bisogno
# 1) Address
# 2) ABI -> Potrebbe essere anche salvata in un JSON
simpleStorageContract = w3.eth.contract(address = transactionReceipt.contractAddress, abi=abi)
# Call -> Simula facendo la chiamata e avendo un valore di ritorno, non effettuano cambiamento di stato (BOTTONI BLU)
# Transact -> Effettua cambiamento di stato nella chain (BOTTONE ARANCIONE)
# Valore iniziale di number
print(simpleStorageContract.functions.getNumber().call())
# Simula l'update, non modifica lo stato della blockchain
print(simpleStorageContract.functions.updateNumber(10).call())
# Ora lo stato della chain sarà modificato
storeTransaction = simpleStorageContract.functions.updateNumber(15).buildTransaction({"chainId": chainId, "from": myAddress, "nonce": nonce + 1, "gasPrice": w3.eth.gas_price})
signedStoreTransaction = w3.eth.account.sign_transaction(storeTransaction, private_key=privateKey)
transactionHash = w3.eth.send_raw_transaction(signedStoreTransaction.rawTransaction)
transactionStoreReceipt = w3.eth.wait_for_transaction_receipt(transactionHash)
print(simpleStorageContract.functions.getNumber().call())