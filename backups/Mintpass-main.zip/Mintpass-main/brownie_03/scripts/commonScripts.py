from attr import asdict
from brownie import network, config, accounts, MockV3Aggregator, Contract, VRFCoordinatorMock, LinkToken
from web3 import Web3

DECIMALS = 8
STARTING_PRICE = 2000.00000000
LOCAL_BLOCKCHAIN_ENVIRONMENTS = ["development", "ganache-local"]
FORKED_ENVIRONMENTS = ["mainnet-fork", "mainnet-fork-dev"]

def getAccount(index = None, id = None):
    # Un altro metodo per caricare un account è accounts.load()
    if index:
        return accounts[index]
    if id:
        accounts.load(id)
    if network.show_active() in LOCAL_BLOCKCHAIN_ENVIRONMENTS or network.show_active() in FORKED_ENVIRONMENTS:
        return accounts[0]
    return accounts.add(config["wallets"]["from_key"])

contractToMock = {
    "eth_usd" : MockV3Aggregator,
    "vrf_coordinator" : VRFCoordinatorMock,
    "link_token" : LinkToken
}



def getContract(contractName):
    """ 
    Questa funzione riceverà i vari parametri dalla config se definiti, altrimenti farà un deploy dei mock e ritornerà
    questi ultimi.

        Args:
            contractName (string)
        Returns;
            brownie.network.contract.ProjectContract: La versione più recente del contratto.
    """
    contractType = contractToMock[contractName]
    if network.show_active() in LOCAL_BLOCKCHAIN_ENVIRONMENTS:
        print(f"leng: {len(contractType)} per {contractName}")
        if len(contractType) <= 0:
            deployMocks(contractType, contractName)
        contract = contractType[-1]
    else:
        contractAddress = config["networks"][network.show_active()][contractName]
        contract = Contract.from_abi(contractType._name, contractAddress, contractType.abi)
    return contract


def deployMocks(contractType, contractName):
    print(f"The active network is {network.show_active()}")
    print(f"Deploying Mocks for {contractName}")
    account = getAccount()
    if contractType == MockV3Aggregator:
        contractType.deploy(DECIMALS, Web3.toWei(STARTING_PRICE, "ether"), {"from" : account})
    elif contractType == LinkToken:
        contractType.deploy({"from" : account})
    elif contractType == VRFCoordinatorMock:
        if len(LinkToken) <= 0:
            deployMocks(LinkToken, "link_token")
        contractType.deploy(LinkToken[-1], {"from" : account})

    print("Mocks Deployed!")

def fundWithLink(address, account = None, linkToken = None, amount = 100000000000000000):
    # account = account se questo è specificato, altrimenti richiama getAccount()
    account = account if account else getAccount()
    linkToken = linkToken if linkToken else getContract("link_token")
    # Abbiamo due strade:
        # 1) Non utilizzando l'interfaccia ma l'ABI
    tx = linkToken.transfer(address, amount, {"from" : account})
    
        # 2) Utilizzando l'interfaccia ma non l'ABI
    #linkTokenContract = interfaces.LinkTokenInterface(linkToken.address)
    #tx = linkTokenContract.transfer(address, amount, {"from" : account})

    tx.wait(1)
    print("Link Transferred")
    return tx