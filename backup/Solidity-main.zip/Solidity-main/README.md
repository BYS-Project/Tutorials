# Solidity
Repo per riassumere un po' le basi di solidity :D <br>
Qui ci sono i vari appunti presi presi da [qui](https://www.youtube.com/watch?v=M576WGiDBdQ) <br>
Per altro consulta il documento nel drive condiviso

## SimpleStorage
Primo file in cui sono contenute le funzionalità di base

## SimpleStorageFactory
Secondo file in cui sono contenute funzionalità un pochino più avanzate (inheritance, import, creazione di SC da parte di un altro SC, get/modifica delle variabili di un SC tramite un altro SC...)

## FundMe
SC contenente delle basi per transazioni (invio e prelievo) e consultazioni ad oracoli. Modifiers, msg.sender e msg.value. Concetto di owner. For, if.
