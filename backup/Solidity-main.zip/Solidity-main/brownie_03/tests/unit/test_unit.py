# Unit Test: test di piccoli pezzi di codice in un sistema isolato - Solitamente in Dev Network
from brownie import Lottery, network, exceptions, accounts
from scripts.commonScripts import LOCAL_BLOCKCHAIN_ENVIRONMENTS, getAccount, fundWithLink, getContract
from scripts.deploy import deploy
from web3 import Web3
import pytest

def testEntranceFee():
    # Essendo un unit test vogliamo che funzioni solamente su un'infrastruttura locale
    if network.show_active() not in LOCAL_BLOCKCHAIN_ENVIRONMENTS:
        pytest.skip()
    
    lottery = getLottery()
    entranceFee = lottery.getEntranceFee()
    # Se il prezzo è di 2000 per ETH, il prezzo sarà 50/2000 = 0.025
    expectedEntranceFee = Web3.toWei(0.0025, "ether")
    assert entranceFee == expectedEntranceFee

def testEnterIfNotStarted():
    # Essendo un unit test vogliamo che funzioni solamente su un'infrastruttura locale
    if network.show_active() not in LOCAL_BLOCKCHAIN_ENVIRONMENTS:
        pytest.skip()

    lottery = getLottery()
    with pytest.raises( (exceptions.VirtualMachineError, ValueError) ):
        lottery.enter({"from" : getAccount(), "value" : lottery.getEntranceFee()})

def testEnterIfStarted():
    # Essendo un unit test vogliamo che funzioni solamente su un'infrastruttura locale
    if network.show_active() not in LOCAL_BLOCKCHAIN_ENVIRONMENTS:
        pytest.skip()

    lottery = getLottery()
    account = getAccount()
    lottery.startLottery({"from" : account})
    lottery.enter({"from" : account, "value" : lottery.getEntranceFee()})
    assert lottery.players(0) == account

def testEndLottery():
    # Essendo un unit test vogliamo che funzioni solamente su un'infrastruttura locale
    if network.show_active() not in LOCAL_BLOCKCHAIN_ENVIRONMENTS:
        pytest.skip()

    lottery = getLottery()
    account = getAccount()
    lottery.startLottery({"from" : account})
    lottery.enter({"from" : account, "value" : lottery.getEntranceFee()})
    fundWithLink(lottery)
    lottery.endLottery({"from" : account})
    assert lottery.lotteryState() == 2 # Equivale al secondo stato (CLOSED)

def testGetsCorrectWinner():
    # Essendo un unit test vogliamo che funzioni solamente su un'infrastruttura locale
    if network.show_active() not in LOCAL_BLOCKCHAIN_ENVIRONMENTS:
        pytest.skip()

    lottery = getLottery()
    account = getAccount()
    lottery.startLottery({"from" : account})
    lottery.enter({"from" : account, "value" : lottery.getEntranceFee()})
    # Entriamo con più account
    lottery.enter({"from" : getAccount(index = 1), "value" : lottery.getEntranceFee()})
    lottery.enter({"from" : getAccount(index = 2), "value" : lottery.getEntranceFee()})
    lottery.enter({"from" : getAccount(index = 3), "value" : lottery.getEntranceFee()})
    fundWithLink(lottery)
    print("-----\nEndind lottery...")
    tx = lottery.endLottery({"from" : account})
    # Cerchiamo un determinato evento
    requestId = tx.events["RequestedRandomness"]["requestId"]
    # Numero randomico deciso a priori
    STATIC_RNG = 30
    # Simuliamo di essere il nodo che sceglie il vincitore
    print("Calling randomness...")
    tx = getContract("vrf_coordinator").callBackWithRandomness(requestId, STATIC_RNG, lottery.address, {"from" : account})
    print("Randomness called")
    winnerAccount = tx.events["WinnerAccount"]["winnerAccount"]
    print(f"Winner found! {winnerAccount}")
    # Trovo in brownie l'account del vincitore
    winnerProfile = None
    for a in accounts:
        if a.address == winnerAccount:
            winnerProfile = a
    # Salvo il bilancio di vincitore e lotteria
    startingAccountBalance = winnerProfile.balance()
    startingLotteryBalance = lottery.balance()
    assert lottery.lastWinner() == winnerAccount
    assert lottery.balance() == 0
    assert winnerProfile.balance() == startingAccountBalance + startingLotteryBalance



def getLottery():
    # Ci serve una lotteria nuova a ogni esecuzione
    #if len(Lottery) <= 0:
        return deploy(None, 0)
    #else: 
    #    return Lottery[-1]