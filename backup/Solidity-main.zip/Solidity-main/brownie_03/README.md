1. Vogliamo fare una lotteria che chi vince riceve ETH partendo da USD
2. Un admin potrà segliere quando la lotteria sarà finita
3. La lotteria selezionerà un vincitore randomicamente
# Non è decentralizzata!