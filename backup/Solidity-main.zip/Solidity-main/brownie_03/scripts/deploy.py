from scripts.commonScripts import getAccount, getContract, fundWithLink
from brownie import Lottery, network, config
import time

def deploy(id, index):
    account = getAccount(id, index)
    lottery = Lottery.deploy(
            getContract("eth_usd").address,
            getContract("vrf_coordinator").address,
            getContract("link_token").address,
            config["networks"][network.show_active()]["fee"],
            config["networks"][network.show_active()]["keyhash"],
            {"from" : account}
        )
    print(f"Deploying with: {getContract('eth_usd')}")
    print("Lottery deployed")
    # Ritorniamo lo SC per i test
    print(lottery)
    return lottery

def startLottery():
    account = getAccount()
    lottery = Lottery[-1]
    tx = lottery.startLottery({"from" : account})
    # Potrebbe accadere che si faccia prima questa transazione di quella precedente
    tx.wait(1)
    print("The lottery is started")

def enterLottery():
    account = getAccount()
    lottery = Lottery[-1]
    # Aggiungiamo un pochino in modo tale da non incappare in problemi
    value = lottery.getEntranceFee() + 100000000
    tx = lottery.enter({"from" : account, "value" : value})
    tx.wait(1)
    print(f"{account} has entered the lottery")

def endLottery():
    account = getAccount()
    lottery = Lottery[-1]
    # Dobbiamo pagare con il contratto che ha i Link Token
    # Dopodichè finiremo la lotteria
    fundWithLink(lottery.address)
    endingTransaction = lottery.endLottery({"from" : account})
    # Stiamo richiedendo una transazione al nodo ChainLink, ci mette del tempo...
        # O aspettiamo con i blocchi
    endingTransaction.wait(1)
        # O aspettiamo con il tempo
    time.sleep(5)
    recentWinners = lottery.getRecentWinners()
    state = lottery.getLotteryState()
    print(f"len: {len(recentWinners)} with status {state}")
    print(f"Lottery won by {recentWinners[-1]}")

def main():
    deploy(id = None, index = 0)
    startLottery()
    enterLottery()
    # endLottery()
