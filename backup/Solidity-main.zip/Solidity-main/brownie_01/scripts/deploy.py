# Importiamo degli account
from brownie import accounts, SimpleStorage, network, config #-> Se volessimo prendere informazioni dalla config di brownie # , NomeSC -> Per importare un contratto già esistente
# Oppure possiamo dare degli account di default a brownie tramite
# brownie accounts new Enrypase
# mettiamo, quindi, la nostra chiave privata per il relativo account


def deployContract():
    account = getAccount()
    print(account)
    # Se avessimo creato un account tramite procedura sopra descritta:
    # account = accounts.load("Enrypase")
    
    # Se volessimo prendere informazioni dalla config di brownie:
    # account = accounts.add(config["wallets"]["from_key"])

    # Tutto quello di Web3.py sarà fatto in automatico
    simpleStorage = SimpleStorage.deploy({"from" : account})
    print(simpleStorage)
    storedValue = simpleStorage.getNumber()
    print("Numero: ", storedValue)

    transaction = simpleStorage.updateNumber(15, {"from" : account})
    newValue = simpleStorage.getNumber()
    print(newValue)

def getAccount():
    if(network.show_active() == "development"):
        return accounts[0]
    else:
        # Se la config è strutturata così
        return accounts.add(config["wallets"]["from_key"])

# Definiamo la funzione principale
def main():
    print("Starting to deploy")
    deployContract()