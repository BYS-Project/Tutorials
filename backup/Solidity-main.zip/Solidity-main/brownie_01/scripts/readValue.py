# Legge un valore da uno smart contract
from brownie import SimpleStorage, accounts, config

def readContract():
    # Tutti gli SC di cui si fa il deploy sono salvati in build/deployments e in un array con lo stesso nome dello SC
    # Con [-1] mi richiamo sempre all'ultimo elemento dell'array
    # Abbiamo sia ABI che Address salvato
    simpleStorage = SimpleStorage[-1]
    number = simpleStorage.getNumber()
    print(number)
def main():
    readContract()